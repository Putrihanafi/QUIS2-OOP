CREATE DATABASE pelangganapp;
USE pelangganapp;

CREATE TABLE pelanggan (
	idpelanggan INT(20) NOT NULL AUTO_INCREMENT,
	nama VARCHAR(255), 
	jumlah VARCHAR(20), 
	diskon VARCHAR(20),
	PRIMARY KEY (idpelanggan) 
);