package pelanggan;

import java.sql.SQLException;

/**
 *
 * @author INSTIKI
 * TGL: 2024-05-16
 */
public class pelangganmain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
//        new jForm1().setVisible(true);
        jForm1 jf = new jForm1();
        jf.setResizable(false);
        jf.setAlwaysOnTop(true);
        jf.setVisible(true);
    }
    
}
